const MYSQL_DB_CONFIG = {
    HOST: "localhost",
    USER: "root",
    PORT: 3306,
    PASSWORD: "",
    DB: "awt_ecom_app_db",
};

module.exports = {
    MYSQL_DB_CONFIG,
};