import React from 'react'
import { Navbar, Product } from "../components"

const Products = () => {
  return (
    <>
      <Navbar />
      <Product />
    </>
  )
}

export default Products