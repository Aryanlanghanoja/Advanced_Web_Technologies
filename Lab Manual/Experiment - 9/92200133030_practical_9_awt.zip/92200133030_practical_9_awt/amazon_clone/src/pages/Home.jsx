import { Navbar, Product } from "../components";

function Home() {
  return (
    <>
      <Navbar />
      <Product />
    </>
  )
}

export default Home