import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
    apiKey: "AIzaSyAiQ_BqpzU-aLwFenwcS8wt7P0zpy2EoKc",
    authDomain: "expense-react-app-12668.firebaseapp.com",
    projectId: "expense-react-app-12668",
    storageBucket: "expense-react-app-12668.firebasestorage.app",
    messagingSenderId: "1005833833721",
    appId: "1:1005833833721:web:0079b17beb17559647e628",
    measurementId: "G-MX7XQCXXGR"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const analytics = getAnalytics(app);
    
export default app;